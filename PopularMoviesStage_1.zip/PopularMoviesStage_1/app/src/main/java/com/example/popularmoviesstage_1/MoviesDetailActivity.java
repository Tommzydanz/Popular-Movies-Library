package com.example.popularmoviesstage_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class MoviesDetailActivity extends AppCompatActivity {

    private static final String URL_IMAGE_PATH = "https://image.tmdb.org/t/p/w185";
    private static final String URL_BACKDROP_PATH = "https://image.tmdb.org/t/p/original";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies_detail);


        Intent intent = getIntent();
        if (intent == null) {
            closeOnError();
        }


        ImageView movie_poster_iv = findViewById(R.id.movie_poster_iv);

        ImageView backdrop_image_iv = findViewById(R.id.image_poster_iv);



        //Updates the details from MovieDetail Intent passed


        String title = getIntent().getStringExtra("title");
        String image_poster = getIntent().getStringExtra("poster");
        String backdrop = getIntent().getStringExtra("backdrop");
        String plot = getIntent().getStringExtra("plot");
        String rating = getIntent().getStringExtra("rating");
        String release = getIntent().getStringExtra("releaseDate");




        assert image_poster != null;
        Picasso.get()
                .load(URL_IMAGE_PATH.concat(image_poster))
                .fit()
                .into(movie_poster_iv);

        assert backdrop != null;
        Picasso.get()
                .load(URL_BACKDROP_PATH.concat(backdrop))
                .fit()
                .into(backdrop_image_iv);

        TextView title_tv = findViewById(R.id.tv_title);
        title_tv.setText(title);

        TextView plot_synopsis_tv = findViewById(R.id.plot_synopsis_tv);
        plot_synopsis_tv.setText(plot);

        TextView rating_tv = findViewById(R.id.tv_rating);
        assert rating != null;
        rating_tv.setText(rating.concat(" /10"));

        TextView release_tv = findViewById(R.id.tv_release);
        release_tv.setText(release);


        setTitle(title);
     }



    private void closeOnError() {
        finish();
    }
}