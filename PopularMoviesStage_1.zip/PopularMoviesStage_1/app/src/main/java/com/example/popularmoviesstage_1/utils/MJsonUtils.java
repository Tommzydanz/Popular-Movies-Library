package com.example.popularmoviesstage_1.utils;

import android.text.TextUtils;

import com.example.popularmoviesstage_1.model.MoviesLab;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MJsonUtils {
    private static final String MOVIE_RESULTS = "results";
    private static final String MOVIE_TITLE = "title";
    private static final String MOVIE_RELEASE_DATE = "release_date";
    private static final String MOVIE_POSTER = "poster_path";
    private static final String MOVIE_BACKDROP = "backdrop_path";
    private static final String MOVIE_RATING = "vote_average";
    private static final String MOVIE_SYNOPSIS = "overview";

    public static List<MoviesLab> parseMoviesLabJson(String moviesLabJson) throws JSONException {

        String title;
        String release_date;
        String poster_path;
        String backdrop_path;
        String vote_average;
        String overview;
        List<MoviesLab> moviesList = new ArrayList<>();
        // Return early
        if (TextUtils.isEmpty(moviesLabJson)) {
            return null;
        }
        JSONObject jsonMovieObj = new JSONObject(moviesLabJson);

        JSONArray resultsArray = jsonMovieObj.getJSONArray(MOVIE_RESULTS);

        for (int i = 0; i < resultsArray.length(); i++){


            JSONObject firstResults = resultsArray.getJSONObject(i);
            title = firstResults.getString(MOVIE_TITLE);
            release_date= firstResults.getString(MOVIE_RELEASE_DATE);
            poster_path= firstResults.getString(MOVIE_POSTER);
            backdrop_path = firstResults.getString(MOVIE_BACKDROP);
            vote_average= firstResults.getString(MOVIE_RATING);
            overview = firstResults.getString(MOVIE_SYNOPSIS);

            MoviesLab moviesLab = new MoviesLab(title, release_date, poster_path, backdrop_path, vote_average, overview);
            moviesList.add(moviesLab);
        }
        return moviesList;
    }
}
